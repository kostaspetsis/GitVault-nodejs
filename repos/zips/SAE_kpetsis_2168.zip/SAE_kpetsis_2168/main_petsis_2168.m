transf_f = find_transf_func_petsis_2168();

zeros_poles_petsis_2168(transf_f);

eliminate_zp_mut_excl_petsis_2168(transf_f);

step_function_petsis_2168(transf_f);