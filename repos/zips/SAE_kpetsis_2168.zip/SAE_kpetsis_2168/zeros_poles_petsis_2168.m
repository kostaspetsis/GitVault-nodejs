function y = zeros_poles_petsis_2168(transfer_f)
  pzmap(transfer_f)
end