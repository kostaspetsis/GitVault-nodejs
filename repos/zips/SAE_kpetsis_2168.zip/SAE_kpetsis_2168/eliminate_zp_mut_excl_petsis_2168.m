function y = eliminate_zp_mut_excl_petsis_2168(transf_f)
  y =  minreal(transf_f)
  pzmap(y)
end